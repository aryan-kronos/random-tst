import { useState, useEffect } from 'react';
import { Volume2, Pause, Play, RotateCcw, Sparkles, FileText, ChevronDown, ChevronUp, Radio } from 'lucide-react';
import { useNarration } from '../hooks/useNarration';
import type { Topic } from '../data/topics';

interface Props {
  topic: Topic;
}

export default function CinematicVoicePlayer({ topic }: Props) {
  const narration = useNarration();
  const [showFullTranscript, setShowFullTranscript] = useState(false);

  // Build the rich narrative script for voice playback
  const fullAudioScript = `${topic.title}. ${topic.subtitle}. ${topic.cinematicVoiceStory} Here are the key pillars of this idea. ${topic.keyPoints.join('. ')}. When you speak, follow your custom 60-second blueprint. Take a deep breath, and let your authentic voice discover the idea.`;

  useEffect(() => {
    narration.stop();
  }, [topic.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const isPlaying = narration.speaking && !narration.paused;

  const handlePlayToggle = () => {
    if (!narration.speaking) {
      narration.speak(fullAudioScript);
    } else if (narration.paused) {
      narration.resume();
    } else {
      narration.pause();
    }
  };

  return (
    <div className="relative overflow-hidden rounded-3xl border border-amber/35 bg-gradient-to-br from-ivory via-parchment/70 to-champagne/60 p-6 sm:p-8 shadow-[0_12px_45px_-15px_rgba(196,162,101,0.35)]">
      {/* Background radial glow */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-radial from-amber/15 to-transparent rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10">
        {/* Header bar */}
        <div className="flex items-center justify-between gap-3 mb-5 flex-wrap">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber to-amber-deep text-ivory grid place-items-center shadow-md shadow-amber/25">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-[0.2em] text-amber-deep font-bold block">
                Cinematic Voice Story
              </span>
              <span className="text-[11px] text-ink-faint">
                Immersive documentary narrative & storytelling breakdown
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={narration.toggleRate}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-ink-wash/20 bg-ivory text-xs font-semibold text-warm-stone hover:border-amber transition"
            >
              <Radio className="w-3 h-3 text-amber-deep" />
              {narration.rate.toFixed(2)}x Speed
            </button>
          </div>
        </div>

        {/* Cinematic Story Excerpt Box */}
        <div className="bg-cream/80 backdrop-blur-xs rounded-2xl border border-amber/20 p-5 sm:p-6 mb-6 shadow-inner relative">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-deep mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            Theatrical Storytelling Arc
          </div>
          <p className="font-editorial italic text-lg sm:text-xl text-espresso-soft leading-relaxed">
            &ldquo;{topic.cinematicVoiceStory}&rdquo;
          </p>
        </div>

        {/* Audio Player Controls & Waveform */}
        <div className="flex flex-col sm:flex-row items-center gap-5">
          {/* Main Play/Pause Button */}
          <button
            onClick={handlePlayToggle}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 rounded-full bg-espresso px-7 py-4 text-sm font-medium tracking-wide text-ivory shadow-xl shadow-espresso/20 hover:bg-espresso-ink hover:scale-105 active:scale-95 transition duration-300 group"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" />
                <span>Pause Narration</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current ml-0.5 group-hover:scale-110 transition" />
                <span>{narration.speaking ? 'Resume Story' : 'Listen to Cinematic Story'}</span>
              </>
            )}
          </button>

          {/* Reset button if active */}
          {narration.speaking && (
            <button
              onClick={narration.stop}
              className="w-11 h-11 rounded-full border border-ink-wash/25 bg-ivory grid place-items-center text-warm-stone hover:border-amber hover:text-amber-deep transition"
              title="Restart story"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}

          {/* Equalizer & Progress Bar */}
          <div className="flex-1 w-full flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs text-ink-faint">
              <span>{isPlaying ? 'Narrating story…' : narration.speaking ? 'Paused' : 'Ready to listen'}</span>
              {isPlaying && (
                <div className="flex items-end gap-[3px] h-4">
                  {[0, 1, 2, 3, 4, 5, 6].map(i => (
                    <span
                      key={i}
                      className="w-[3px] rounded-full bg-gradient-to-t from-amber to-amber-deep"
                      style={{
                        animation: `eq 800ms ${i * 90}ms ease-in-out infinite`,
                        height: '60%',
                      }}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Progress line */}
            <div className="h-2 rounded-full bg-ink-wash/15 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-amber via-amber-glow to-amber-deep transition-[width] duration-300"
                style={{ width: `${Math.round(narration.progress * 100)}%` }}
              />
            </div>
          </div>

          {/* Transcript toggle */}
          <button
            onClick={() => setShowFullTranscript(!showFullTranscript)}
            className="text-xs text-warm-stone hover:text-amber-deep flex items-center gap-1 font-medium transition whitespace-nowrap"
          >
            <FileText className="w-3.5 h-3.5 text-amber-deep" />
            {showFullTranscript ? 'Hide script' : 'View full script'}
            {showFullTranscript ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>

        {/* Collapsible Full Transcript */}
        {showFullTranscript && (
          <div className="mt-5 pt-5 border-t border-ink-wash/10 text-xs sm:text-sm text-warm-stone leading-relaxed space-y-2 bg-ivory/60 rounded-xl p-4">
            <div className="font-semibold text-espresso">Full Voice Narration Script:</div>
            <p>{fullAudioScript}</p>
          </div>
        )}
      </div>
    </div>
  );
}
